# plugin_googlemaps
This is the Joomla plugin Google maps by Reumer based on Google Maps API version 3.

You can put the {mosmap} with parameters anywhere in content in Joomla: intro text or main text of an article, components and modules. You can see examples and documentation on my demo site: http://tech.reumer.net.

Look at the wiki page for more information: https://github.com/jmosmap/plugin_googlemaps/wiki/Welcome
