<?php
$cp2 = 'Designed by <a href="http://www.plustheme.com" 
target="_blank" title="www.plustheme.com">plustheme.com</a>';

$melding = '<div class="er">author footer link can be edited or disabled only in full version</div>';

if (strcmp($cp, $cp2) !== 0) {
    echo $melding;
}
?>
